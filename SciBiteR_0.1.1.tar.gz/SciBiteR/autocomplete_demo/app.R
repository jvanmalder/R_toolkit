library(shiny)

# UI
ui <- fluidPage(
  textInput(inputId = 'text', label = 'text'),
  uiOutput("autobox"),
  textOutput("autoid")
)

# Server
server <- function(input, output, session) {
  autotext <- reactive({ input$text })
  output$autobox <- renderUI(
    if (nchar(autotext()) < 3) {
      selectInput(inputId = 'autobox', label = 'Autocomplete', choices = autotext())
    }
    else {
      auto <- autocomplete(endpoint <- "http://localhost:9090/termite/toolkit/autocomplete.api",
                           input <- autotext(),
                           VOCab = "SPECIES",
                           taxon = '')
      reactiveauto <- auto$id
      names(reactiveauto) <- auto$label
      selectInput(inputId = 'autobox', label = 'Autocomplete', choices = reactiveauto)
    }

  )
  output$autoid <- renderText({ input$autobox })
}

# Run app
shinyApp(ui = ui, server = server)
